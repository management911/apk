import { CommandItem, HelpTopic } from '../types';

export const COMMANDS_DATA: CommandItem[] = [
  // --- ADB Basic ---
  {
    id: 'adb-devices',
    command: 'adb devices',
    descriptionAr: 'عرض قائمة بالأجهزة المتصلة بالكمبيوتر والجاهزة لاستقبال الأوامر.',
    descriptionEn: 'List all connected Android devices with debugging enabled.',
    category: 'adb-basic',
    example: 'adb devices'
  },
  {
    id: 'adb-connect',
    command: 'adb connect [IP]:[Port]',
    descriptionAr: 'الاتصال بجهاز أندرويد عبر الشبكة اللاسلكية (Wi-Fi) باستخدام بروتوكول TCP/IP.',
    descriptionEn: 'Connect to a device over Wi-Fi/TCP with its IP address and port.',
    category: 'adb-basic',
    example: 'adb connect 192.168.1.100:5555'
  },
  {
    id: 'adb-disconnect',
    command: 'adb disconnect',
    descriptionAr: 'قطع الاتصال اللاسلكي بجميع الأجهزة أو جهاز معين.',
    descriptionEn: 'Disconnect from all or a specific wireless debugging target.',
    category: 'adb-basic',
    example: 'adb disconnect'
  },
  {
    id: 'adb-push',
    command: 'adb push [LocalPath] [RemotePath]',
    descriptionAr: 'إرسال ملف أو مجلد من جهاز الكمبيوتر الخاص بك إلى ذاكرة الهاتف.',
    descriptionEn: 'Copy a local file or folder from your computer to the Android device.',
    category: 'adb-basic',
    example: 'adb push app.apk /sdcard/Download/'
  },
  {
    id: 'adb-pull',
    command: 'adb pull [RemotePath] [LocalPath]',
    descriptionAr: 'سحب (تحميل) ملف أو مجلد من الهاتف إلى جهاز الكمبيوتر الخاص بك.',
    descriptionEn: 'Copy a remote file or folder from the Android device to your computer.',
    category: 'adb-basic',
    example: 'adb pull /sdcard/Photos/image.jpg ./downloads/'
  },
  {
    id: 'adb-install',
    command: 'adb install [ApkPath]',
    descriptionAr: 'تثبيت تطبيق (ملف APK) من الكمبيوتر مباشرة على الهاتف المتصل.',
    descriptionEn: 'Install a standard Android package (.apk) from computer onto the device.',
    category: 'adb-basic',
    example: 'adb install game.apk'
  },
  {
    id: 'adb-uninstall',
    command: 'adb uninstall [PackageName]',
    descriptionAr: 'إلغاء تثبيت تطبيق من الهاتف باستخدام اسم الحزمة البرمجية الخاصة به.',
    descriptionEn: 'Uninstall an Android application using its unique package name.',
    category: 'adb-basic',
    example: 'adb uninstall com.whatsapp'
  },

  // --- ADB Advanced ---
  {
    id: 'adb-shell',
    command: 'adb shell',
    descriptionAr: 'فتح سطر أوامر تفاعلي (Linux shell) داخل نظام الأندرويد مباشرة.',
    descriptionEn: 'Start an interactive remote terminal shell to run commands on the device.',
    category: 'adb-advanced',
    example: 'adb shell'
  },
  {
    id: 'adb-bugreport',
    command: 'adb bugreport [ZipPath]',
    descriptionAr: 'إنشاء تقرير أخطاء شامل للنظام يحتوي على سجلات كاملة وملفات تشخيصية.',
    descriptionEn: 'Generate a comprehensive diagnostic report zip containing system logs.',
    category: 'adb-advanced',
    example: 'adb bugreport ./bugreport.zip'
  },
  {
    id: 'adb-reboot',
    command: 'adb reboot',
    descriptionAr: 'إعادة تشغيل الهاتف بشكل طبيعي.',
    descriptionEn: 'Reboot the Android device normally.',
    category: 'adb-advanced',
    example: 'adb reboot'
  },
  {
    id: 'adb-reboot-recovery',
    command: 'adb reboot recovery',
    descriptionAr: 'إعادة تشغيل الهاتف والدخول إلى وضع الاسترداد (Recovery Mode).',
    descriptionEn: 'Reboot the device into system Recovery mode.',
    category: 'adb-advanced',
    example: 'adb reboot recovery'
  },
  {
    id: 'adb-reboot-bootloader',
    command: 'adb reboot bootloader',
    descriptionAr: 'إعادة تشغيل الهاتف والدخول إلى وضع الـ Bootloader / Fastboot لتثبيت الرومات ومفاتيح النظام.',
    descriptionEn: 'Reboot the device into Fastboot/Bootloader mode.',
    category: 'adb-advanced',
    example: 'adb reboot bootloader'
  },

  // --- Package Manager (pm) ---
  {
    id: 'pm-list-packages',
    command: 'pm list packages',
    descriptionAr: 'عرض حزم وتطبيقات الأندرويد المثبتة على الهاتف.',
    descriptionEn: 'List all installed packages and application identifiers on the device.',
    category: 'package-manager',
    example: 'pm list packages'
  },
  {
    id: 'pm-list-packages-3',
    command: 'pm list packages -3',
    descriptionAr: 'عرض حزم التطبيقات التابعة لجهات خارجية فقط (تطبيقات المستخدم وليست تطبيقات النظام).',
    descriptionEn: 'List only third-party (non-system) developer packages.',
    category: 'package-manager',
    example: 'pm list packages -3'
  },
  {
    id: 'pm-list-packages-s',
    command: 'pm list packages -s',
    descriptionAr: 'عرض حزم تطبيقات النظام الأساسية المدمجة مع الروم فقط.',
    descriptionEn: 'List only core system packages loaded into OS partition.',
    category: 'package-manager',
    example: 'pm list packages -s'
  },
  {
    id: 'pm-path',
    command: 'pm path [PackageName]',
    descriptionAr: 'عرض المسار الكامل لملف الـ APK الخاص بتطبيق معين مثبت على الجهاز.',
    descriptionEn: 'Get the exact installation path directory for a given package identifier.',
    category: 'package-manager',
    example: 'pm path com.android.chrome'
  },
  {
    id: 'pm-clear',
    command: 'pm clear [PackageName]',
    descriptionAr: 'مسح جميع البيانات والملفات المؤقتة المخزنة لتطبيق معين (إعادة ضبط المصنع للتطبيق).',
    descriptionEn: 'Delete all runtime user data and cache of an app, resetting it completely.',
    category: 'package-manager',
    example: 'pm clear com.instagram.android'
  },
  {
    id: 'pm-enable',
    command: 'pm enable [PackageName]',
    descriptionAr: 'تنشيط تطبيق معين كان معطلاً في النظام.',
    descriptionEn: 'Enable/activate a system package or user application.',
    category: 'package-manager',
    example: 'pm enable com.google.android.youtube'
  },
  {
    id: 'pm-disable',
    command: 'pm disable-user [PackageName]',
    descriptionAr: 'تعطيل تطبيق معين وإخفاء أيقونته بدون حذفه (مفيد لتطبيقات النظام غير المرغوبة).',
    descriptionEn: 'Disable and freeze a built-in bloatware package for the current system user.',
    category: 'package-manager',
    example: 'pm disable-user com.sec.android.app.sbrowser'
  },

  // --- Activity Manager (am) ---
  {
    id: 'am-start',
    command: 'am start -n [PackageName]/[ActivityName]',
    descriptionAr: 'تشغيل واجهة (Activity) أو شاشة معينة داخل تطبيق معين مباشرة.',
    descriptionEn: 'Launch a specific UI component/activity within an Android app.',
    category: 'activity-manager',
    example: 'am start -n com.android.settings/.Settings'
  },
  {
    id: 'am-force-stop',
    command: 'am force-stop [PackageName]',
    descriptionAr: 'إيقاف تشغيل التطبيق بالكامل بالقوة وإنهاء عملياته الخلفية.',
    descriptionEn: 'Force kill all running process instances linked with a package.',
    category: 'activity-manager',
    example: 'am force-stop com.spotify.music'
  },
  {
    id: 'am-broadcast',
    command: 'am broadcast -a [ActionName]',
    descriptionAr: 'إرسال نية بث (Broadcast Intent) على مستوى النظام للتنبيه أو الاختبار.',
    descriptionEn: 'Send a system-wide broadcast intent action parameter.',
    category: 'activity-manager',
    example: 'am broadcast -a android.intent.action.BOOT_COMPLETED'
  },

  // --- System Info & WM ---
  {
    id: 'getprop',
    command: 'getprop [PropertyKey]',
    descriptionAr: 'عرض قيمة خاصية معينة من خصائص نظام الأندرويد مثل رقم الطراز والإصدار.',
    descriptionEn: 'Query Android build property parameters and internal parameters.',
    category: 'system-info',
    example: 'getprop ro.build.version.release'
  },
  {
    id: 'getprop-all',
    command: 'getprop',
    descriptionAr: 'عرض جميع قيم وخصائص نظام الأندرويد المتاحة دفعة واحدة.',
    descriptionEn: 'Dump all system properties, build variables, and configurations.',
    category: 'system-info',
    example: 'getprop'
  },
  {
    id: 'dumpsys-battery',
    command: 'dumpsys battery',
    descriptionAr: 'الحصول على معلومات تفصيلية عن حالة البطارية (النسبة، درجة الحرارة، الفولت والجهد الكهربائي).',
    descriptionEn: 'Get detailed diagnostics about battery state, scale, voltage, and health.',
    category: 'system-info',
    example: 'dumpsys battery'
  },
  {
    id: 'wm-size',
    command: 'wm size',
    descriptionAr: 'عرض أو تغيير أبعاد دقة الشاشة (Resolution) الحالية للجهاز.',
    descriptionEn: 'Query or change the native/forced display screen resolution.',
    category: 'system-info',
    example: 'wm size 1080x1920'
  },
  {
    id: 'wm-density',
    command: 'wm density',
    descriptionAr: 'عرض أو تغيير كثافة البكسلات (DPI) في واجهة الهاتف للتحكم في حجم الخط والرموز.',
    descriptionEn: 'Query or change the frame display physical density scale of the UI.',
    category: 'system-info',
    example: 'wm density 440'
  },
  {
    id: 'wm-size-reset',
    command: 'wm size reset',
    descriptionAr: 'إعادة دقة الشاشة إلى وضعها الافتراضي المتوافق مع شاشة الهاتف.',
    descriptionEn: 'Reset forced display dimensions back to original hardware settings.',
    category: 'system-info',
    example: 'wm size reset'
  },
  {
    id: 'wm-density-reset',
    command: 'wm density reset',
    descriptionAr: 'إعادة كثافة بكسلات الشاشة (DPI) إلى الوضع الافتراضي لضبط أبعاد العرض الحقيقية.',
    descriptionEn: 'Reset UI density (DPI) scaling to hardware defaults.',
    category: 'system-info',
    example: 'wm density reset'
  },
  {
    id: 'logcat',
    command: 'logcat',
    descriptionAr: 'عرض البث المباشر لسجل النظام بشكل فوري، وهي أهم أداة لتتبع الأخطاء والتطبيقات للبرمجة.',
    descriptionEn: 'Stream runtime Android system logs in real-time, highly critical for debugging.',
    category: 'system-info',
    example: 'logcat'
  },
  {
    id: 'logcat-clear',
    command: 'logcat -c',
    descriptionAr: 'مسح أرشيف سجلات النظام المخزنة وبدء التسجيل من جديد لتسهيل المراقبة.',
    descriptionEn: 'Flush the entire system logcat buffer to start debugging fresh.',
    category: 'system-info',
    example: 'logcat -c'
  },

  // --- Terminal Basic ---
  {
    id: 'sh-ls',
    command: 'ls',
    descriptionAr: 'عرض قائمة بالملفات والمجلدات الموجودة في المسار النشط حالياً.',
    descriptionEn: 'List all visible files and directories inside the current paths.',
    category: 'terminal-basic',
    example: 'ls -la'
  },
  {
    id: 'sh-cd',
    command: 'cd [Directory]',
    descriptionAr: 'تغيير مجلد العمل الحالي والانتقال عبر مسارات الذاكرة والملفات.',
    descriptionEn: 'Change current working directory to the target path address.',
    category: 'terminal-basic',
    example: 'cd /sdcard/Download'
  },
  {
    id: 'sh-pwd',
    command: 'pwd',
    descriptionAr: 'طباعة مسار المجلد الحالي الذي تتواجد فيه الآن لتحديد مكانك.',
    descriptionEn: 'Print the complete path of the current directory.',
    category: 'terminal-basic',
    example: 'pwd'
  },
  {
    id: 'sh-mkdir',
    command: 'mkdir [DirName]',
    descriptionAr: 'إنشاء مجلد جديد بالاسم المحدد في المجلد الحالي.',
    descriptionEn: 'Create a new empty folder subdirectory under current position.',
    category: 'terminal-basic',
    example: 'mkdir my_backup'
  },
  {
    id: 'sh-touch',
    command: 'touch [FileName]',
    descriptionAr: 'إنشاء ملف نصي أو مستند فارغ جديد وتحديث تاريخ الوصول إليه.',
    descriptionEn: 'Create a new blank empty file or update timestamps of existing.',
    category: 'terminal-basic',
    example: 'touch config.txt'
  },
  {
    id: 'sh-rm',
    command: 'rm [FileName]',
    descriptionAr: 'حذف ملف محدد بشكل دائم من مساحة تخزين الجهاز.',
    descriptionEn: 'Remove or delete a specific file permanently from the file system.',
    category: 'terminal-basic',
    example: 'rm old_cache.log'
  },
  {
    id: 'sh-rmrf',
    command: 'rm -rf [DirName]',
    descriptionAr: 'حذف المجلد وكل ما يحتويه من ملفات ومجلدات فرعية بالقوة وبشكل نهائي وبدون تأكيد (احذر عند استخدامه!).',
    descriptionEn: 'Recursively force-delete a directory and all of its inner contents.',
    category: 'terminal-basic',
    example: 'rm -rf garbage_dir'
  },
  {
    id: 'sh-cat',
    command: 'cat [FileName]',
    descriptionAr: 'عرض وقراءة محتوى ملف نصي بسرعة على شاشة الطرفية.',
    descriptionEn: 'Print the physical text content of a file directly to the window.',
    category: 'terminal-basic',
    example: 'cat welcome_note.txt'
  },
  {
    id: 'sh-echo',
    command: 'echo "[Text]" > [FileName]',
    descriptionAr: 'طباعة نص على الشاشة، أو إنشاء/استبدال محتوى ملف نصي بعلامة التوجيه > .',
    descriptionEn: 'Print custom text to shell, or overwrite/create a file using > redirect.',
    category: 'terminal-basic',
    example: 'echo "device_ready=1" > status.cfg'
  },
  {
    id: 'sh-echo-append',
    command: 'echo "[Text]" >> [FileName]',
    descriptionAr: 'إلحاق وإضافة سطر نصي في نهاية الملف دون حذف محتواه السابق بعلامة >> .',
    descriptionEn: 'Append a new text line to the end of a file without overwriting using >>.',
    category: 'terminal-basic',
    example: 'echo "new_line=true" >> status.cfg'
  },
  {
    id: 'sh-grep',
    command: 'grep [Pattern] [FileName]',
    descriptionAr: 'البحث عن الكلمات والجمل المطابقة داخل ملف نصي محدد وعرض السطور المطابقة.',
    descriptionEn: 'Search for specific text patterns or words inside a physical file.',
    category: 'terminal-basic',
    example: 'grep Pixel /system/build.prop'
  },
  {
    id: 'sh-grep-pipe',
    command: '[Command] | grep [Pattern]',
    descriptionAr: 'استخدام الأنبوب | لربط الأوامر والفلترة، لعرض الأسطر التي تحتوي على الكلمة فقط من مخرجات الأمر السابق.',
    descriptionEn: 'Use pipe operator | to filter output lines of any active terminal command.',
    category: 'terminal-basic',
    example: 'getprop | grep version'
  },
  {
    id: 'sh-alias',
    command: 'alias [Shortcut]=\'[Command]\'',
    descriptionAr: 'إنشاء اختصار لسطر أوامر لتنفيذه بكلمة واحدة، أو عرض جميع الاختصارات السابقة عند كتابة alias فقط.',
    descriptionEn: 'Create a shortcut command alias, or print all active custom defined shortcuts.',
    category: 'terminal-basic',
    example: 'alias sys=\'neofetch\''
  },
  {
    id: 'sh-unalias',
    command: 'unalias [Shortcut]',
    descriptionAr: 'حذف وإبطال اختصار مسبق قمت بإنشائه في الطرفية.',
    descriptionEn: 'Remove and invalidate a previously defined shortcut command alias.',
    category: 'terminal-basic',
    example: 'unalias sys'
  },
  {
    id: 'sh-chmod',
    command: 'chmod [Permissions] [FileName]',
    descriptionAr: 'تعديل صلاحيات الوصول والقراءة والكتابة والتشغيل لملف معين (مثال: +x للتشغيل كـ سكربت).',
    descriptionEn: 'Modify the folder or file read, write, and execute permissions grid.',
    category: 'terminal-basic',
    example: 'chmod 755 run_script.sh'
  },
  {
    id: 'sh-dir',
    command: 'dir',
    descriptionAr: 'عرض محتويات المجلد الحالي بالتفصيل الكامل وحجم الملفات ونوعها بأسلوب كلاسيكي.',
    descriptionEn: 'Display current directory contents with detailed sizes and style information.',
    category: 'terminal-basic',
    example: 'dir'
  },
  {
    id: 'sh-mv',
    command: 'mv [Source] [Destination]',
    descriptionAr: 'نقل ملف أو مجلد من مكان لآخر، أو إعادة تسمية الملف في مكانه الحالي.',
    descriptionEn: 'Move or rename a file or folder within the local terminal file structure.',
    category: 'terminal-basic',
    example: 'mv welcome_note.txt note.txt'
  },
  {
    id: 'sh-cp',
    command: 'cp [Source] [Destination]',
    descriptionAr: 'نسخ محتوى ملف بالكامل لإنشاء نسخة جديدة منه في مسار آخر أو بنفس المجلد.',
    descriptionEn: 'Copy full source file structures into an alternative destination block.',
    category: 'terminal-basic',
    example: 'cp welcome_note.txt backup_note.txt'
  },
  {
    id: 'sh-get',
    command: 'get [URL/File]',
    descriptionAr: 'تحميل ملف خارجي وحفظه في مساحة هاتفك، أو إرسال وتنزيل ملف داخلي من الهاتف مباشرة لمتصفحك.',
    descriptionEn: 'Simulate high speed download to root, or download VFS files directly as browser blob.',
    category: 'terminal-basic',
    example: 'get https://example.com/api/firmware.bin'
  },
  {
    id: 'sh-apt-install',
    command: 'apt-install [PackageName]',
    descriptionAr: 'تثبيت سريع ومباشر لحزم المطورين والبرامج الإضافية عبر مدير الحزم المتقدم APT.',
    descriptionEn: 'Instantly download and set up additional system packages via advanced packaging tool APT.',
    category: 'termux',
    example: 'apt-install python'
  },
  {
    id: 'sh-ping',
    command: 'ping [Host]',
    descriptionAr: 'فحص الاتصال والشبكة من الهاتف وسرعة استجابة الخوادم المضيفة كـ google.com.',
    descriptionEn: 'Check host network connection parameters and echo packets return timers.',
    category: 'terminal-basic',
    example: 'ping google.com'
  },

  // --- Termux Specific ---
  {
    id: 'termux-pkg-update',
    command: 'pkg update && pkg upgrade',
    descriptionAr: 'تحديث مستودعات التطبيقات وحزم ترمكس والبرامج المثبتة إلى أحدث إصدار.',
    descriptionEn: 'Fetch the latest Termux package lists and upgrade existing modules.',
    category: 'termux',
    example: 'pkg update && pkg upgrade'
  },
  {
    id: 'termux-pkg-install',
    command: 'pkg install [PackageName]',
    descriptionAr: 'تثبيت برنامج أو أداة جديدة داخل بيئة Termux (مثل python، git، curl، nano).',
    descriptionEn: 'Download and set up programs inside Termux like curl, python or nodejs.',
    category: 'termux',
    example: 'pkg install python git'
  },
  {
    id: 'termux-setup-storage',
    command: 'termux-setup-storage',
    descriptionAr: 'طلب ومنح تطبيق Termux صلاحية الوصول إلى ملفات ذاكرة الهاتف الداخلية (Shared Storage).',
    descriptionEn: 'Grant Termux permission to lock and link with standard mobile storage path.',
    category: 'termux',
    example: 'termux-setup-storage'
  },
  {
    id: 'termux-battery',
    command: 'termux-battery-status',
    descriptionAr: 'استدعاء معلومات بطارية الهاتف عبر واجهة برمجية مصغرة لـ Termux (يتطلب تثبيت Termux:API).',
    descriptionEn: 'Call detailed peripheral live battery report using Termux APIs integrations.',
    category: 'termux',
    example: 'termux-battery-status'
  },
  {
    id: 'termux-vibrate',
    command: 'termux-vibrate -d [Duration]',
    descriptionAr: 'جعل الهاتف يهتز لعدد من الأجزاء من الثانية لمشاريع البرمجة أو الإشعار.',
    descriptionEn: 'Execute a micro hardware physical vibration pulse on the Android phone.',
    category: 'termux',
    example: 'termux-vibrate -d 500'
  },

  // --- Root & Advanced ---
  {
    id: 'sh-su',
    command: 'su',
    descriptionAr: 'طلب صلاحية الروت (SuperUser) وإتاحة الوصول الكامل والتعديل على ملفات النظام المحمية.',
    descriptionEn: 'Request root (SuperUser) access authorization to override lock blocks.',
    category: 'termux',
    example: 'su'
  }
];

export const HELP_TOPICS: { [key: string]: HelpTopic } = {
  developerOptions: {
    titleAr: 'تفعيل خيارات المطور وتصحيح USB (USB Debugging)',
    titleEn: 'Enable Developer Options & USB Debugging',
    steps: [
      'افتح إعدادات الهاتف (Settings).',
      'انزل لأسفل واضغط على "حول الهاتف" (About Phone).',
      'اضغط على "معلومات البرنامج" (Software Information).',
      'ابحث عن "رقم الإصدار" (Build Number) واضغط عليه 7 مرات متتالية حتى يظهر إشعار "أنت الآن مطور برامج!".',
      'ارجع للخلف إلى قائمة الإعدادات الرئيسية، ستجد قسماً جديداً باسم "خيارات المطور" (Developer Options) قد ظهر.',
      'افتح خيارات المطور وقّم بتفعيل خيار "تصحيح أخطاء USB" (USB Debugging).',
      'قم بتوصيل الهاتف بالكمبيوتر، سيظهر لك طلب إذن تصحيح الأخطاء لرمز الكمبيوتر، اضغط على "السماح دائماً" (Always Allow).'
    ]
  },
  wirelessAdb: {
    titleAr: 'توصيل ADB لاسلكياً عبر الواي فاي (Wi-Fi Wireless Debugging)',
    titleEn: 'Connect ADB wirelessly over Wi-Fi network',
    steps: [
      'تأكد من أن الهاتف والكمبيوتر متصلان بنفس شبكة الواي فاي (Wi-Fi).',
      'من خيارات المطور بالهاتف، قم بتفعيل "تصحيح الأخطاء اللاسلكي" (Wireless Debugging).',
      'اضغط على الخيار نفسه للدخول إلى واجهته، وستجد عنوان الـ IP ورقم المنفذ (Port) والـ Pairing Code.',
      'على الكمبيوتر، افتح الطرفية واكتب: adb pair IP:Port (أدخل قيم Pairing الموضحة على شاشة الهاتف).',
      'سيسألك سطر الأوامر عن الـ Pairing Code، اكتب الكود الموضح في الهاتف واضغط Enter.',
      'بعد النجاح، اكتب الأمر للاتصال الفعلي: adb connect IP:Port (استخدم عنوان IP والمنفذ الموضح في الصفحة الرئيسية للتصحيح اللاسلكي).',
      'الآن الهاتف متصل لاسلكياً بالكامل ويمكنك فصل الكبل واستخدام الأوامر كالمعتاد!'
    ]
  },
  termuxSetup: {
    titleAr: 'إعداد بيئة Termux وتثبيت أولى لغات البرمجة',
    titleEn: 'Setup Termux terminal & install first tools',
    steps: [
      'قم بتحميل تطبيق Termux من متجر موثوق (ينصح بنسخة F-Droid الرسمية المحدثة، لأن نسخة متجر Google Play معطلة التحديثات حاليا).',
      'افتح التطبيق، ستظهر لك واجهة موجه الأوامر باللون الأسود والرمادي.',
      'أول تحديث للنظام وحزم البرامج يتطلب كتابة: pkg update && pkg upgrade ثم اضغط Enter.',
      'أثناء التحديث سيطلب إذن الموافقة واصل بالضغط على المفتاح Y ثم Enter لنصف دقيقة.',
      'إذا أردت ربط ذاكرة الهاتف لقراءة الملفات والصور، اكتب الأمر: termux-setup-storage ووافق على طلب إذن الهاتف.',
      'الآن يمكنك تثبيت لغات وأدوات أساسية، مثلاً بايثون: pkg install python، أو أداة git الشهيرة لتنزيل المشاريع: pkg install git.'
    ]
  }
};
