export interface CommandItem {
  id: string;
  command: string;
  descriptionAr: string;
  descriptionEn: string;
  category: 'adb-basic' | 'adb-advanced' | 'package-manager' | 'activity-manager' | 'terminal-basic' | 'system-info' | 'termux';
  example: string;
}

export interface FSNode {
  name: string;
  type: 'file' | 'dir';
  content?: string;
  children?: { [key: string]: FSNode };
}

export interface TerminalHistoryItem {
  id: string;
  text: string;
  type: 'input' | 'output' | 'error' | 'success' | 'warning' | 'ascii' | 'nano' | 'system';
  timestamp: string;
}

export interface HelpTopic {
  titleAr: string;
  titleEn: string;
  steps: string[];
}
